import { useEffect, useRef, useState, useCallback } from 'react'
import Head from 'next/head'
import {
  fetchWeather, fetchSeaWeather, fetchEarthquakes, fetchISS, fetchStorms,
  getVolcanoes, getFloods, WEATHER_GRID,
  wmoLabel, windDir, sunPos, fmtTime, fmtDay,
  magColor, magSize, alertCol, uvLabel
} from '../lib/api'

/* ══════════════════════════════════════════════════════════════
   CSS inline
══════════════════════════════════════════════════════════════ */
const CSS = `
.wv{position:relative;width:100%;height:100%;overflow:hidden;font-family:'Inter',sans-serif}
.wv-map{position:absolute;inset:0;z-index:0}

/* Header */
.wv-hdr{position:absolute;top:0;left:0;right:0;z-index:600;display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:linear-gradient(to bottom,rgba(11,17,32,.99) 55%,transparent);gap:8px;pointer-events:none}
.wv-logo{display:flex;align-items:center;gap:9px;pointer-events:auto}
.wv-logo em{font-size:25px;font-style:normal;line-height:1}
.wv-logo-n{font-size:16px;font-weight:800;color:#f1f5f9;letter-spacing:-.03em;line-height:1.1}
.wv-logo-t{font-size:9px;color:#475569;font-weight:400;letter-spacing:.05em;text-transform:uppercase}
.wv-hint{font-size:11px;color:#64748b;background:rgba(30,41,59,.9);border:1px solid rgba(255,255,255,.08);border-radius:99px;padding:5px 13px;pointer-events:auto;display:none}
@media(min-width:560px){.wv-hint{display:block}}

/* Panneau gauche */
.wv-left{position:absolute;top:64px;left:10px;z-index:600;display:flex;flex-direction:column;gap:7px;max-height:calc(100vh - 120px);overflow-y:auto;overflow-x:visible;padding-right:2px;animation:slideR .3s ease both}
.wv-pnl{background:rgba(11,17,32,.94);border:1px solid rgba(255,255,255,.09);border-radius:12px;padding:11px;backdrop-filter:blur(18px);box-shadow:0 4px 28px rgba(0,0,0,.55);min-width:168px}
.wv-pnl-h{font-size:8px;text-transform:uppercase;letter-spacing:.12em;color:#475569;font-weight:700;margin-bottom:7px;padding:0 2px}

/* Globe bouton */
.wv-gbtn{width:100%;display:flex;align-items:center;gap:8px;background:rgba(56,189,248,.1);border:1px solid rgba(56,189,248,.25);border-radius:8px;padding:9px 11px;cursor:pointer;font-family:inherit;font-size:12px;font-weight:600;color:#38bdf8;transition:all .15s}
.wv-gbtn:hover{background:rgba(56,189,248,.18)}
.wv-gbtn em{font-size:16px;font-style:normal}

/* Toggles */
.wv-tog{display:flex;align-items:center;gap:8px;padding:6px 7px;border-radius:7px;cursor:pointer;background:none;border:none;width:100%;font-family:inherit;font-size:12px;color:#cbd5e1;transition:background .15s;text-align:left}
.wv-tog:hover{background:rgba(255,255,255,.05)}
.wv-tog em{font-size:14px;font-style:normal;flex-shrink:0}
.wv-tog span{flex:1}
.wv-sw{width:29px;height:16px;border-radius:99px;background:#1e293b;position:relative;flex-shrink:0;transition:background .2s;border:1px solid rgba(255,255,255,.08)}
.wv-sw.on{background:#0ea5e9}
.wv-sw::after{content:'';position:absolute;top:2px;left:2px;width:10px;height:10px;border-radius:50%;background:#fff;transition:transform .2s;box-shadow:0 1px 3px rgba(0,0,0,.4)}
.wv-sw.on::after{transform:translateX(13px)}

/* Légende */
.wv-leg{display:flex;align-items:center;gap:6px;font-size:9px;color:#64748b;padding:2px 3px}
.wv-leg-d{width:8px;height:8px;border-radius:50%;flex-shrink:0}

/* Barre bas */
.wv-bar{position:absolute;bottom:26px;left:50%;transform:translateX(-50%);z-index:600;display:flex;align-items:center;gap:9px;background:rgba(11,17,32,.92);border:1px solid rgba(255,255,255,.09);border-radius:99px;padding:6px 14px;font-size:10px;color:#64748b;box-shadow:0 4px 24px rgba(0,0,0,.5);white-space:nowrap;animation:fadeUp .3s ease .2s both;max-width:calc(100vw - 20px);overflow:hidden}
.wv-bar-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;animation:pulse 2s ease-in-out infinite}
.wv-bar-sep{width:1px;height:11px;background:rgba(255,255,255,.08);flex-shrink:0}

/* Loader */
.wv-load{position:absolute;inset:0;background:#0b1120;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:2000;gap:14px}
.wv-spin{width:38px;height:38px;border:3px solid rgba(56,189,248,.15);border-top-color:#38bdf8;border-radius:50%;animation:spin .8s linear infinite}
.wv-load-t{font-size:12px;color:#475569;font-weight:500}

/* Popup météo détaillé (au clic) */
.wp{font-family:'Inter',sans-serif;width:min(340px,92vw)}
.wp-hd{padding:13px 36px 10px 14px;background:rgba(30,41,59,.6);border-bottom:1px solid rgba(255,255,255,.07)}
.wp-coord{font-family:'JetBrains Mono',monospace;font-size:10px;color:#475569}
.wp-tz{font-size:11px;color:#64748b;margin-top:2px}
.wp-main{padding:18px 14px 12px;text-align:center;border-bottom:1px solid rgba(255,255,255,.07)}
.wp-emo{font-size:36px;line-height:1}
.wp-tmp{font-size:50px;font-weight:300;color:#f1f5f9;line-height:1;margin:6px 0 4px}
.wp-tmp sup{font-size:20px;color:#64748b}
.wp-feels{font-size:11px;color:#64748b}
.wp-dsc{font-size:13px;font-weight:500;color:#94a3b8;margin-top:3px}
.wp-mm{display:flex;justify-content:center;gap:18px;margin-top:8px}
.wp-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:rgba(255,255,255,.06)}
.wp-c{background:#0f172a;padding:11px 12px}
.wp-c-i{font-size:15px}
.wp-c-l{font-size:8px;text-transform:uppercase;letter-spacing:.08em;color:#475569;font-weight:700;margin:4px 0 1px}
.wp-c-v{font-size:16px;font-weight:700;color:#f1f5f9;line-height:1.2}
.wp-c-s{font-size:9px;color:#64748b;margin-top:2px}
.wp-sun{padding:11px 14px 6px;border-top:1px solid rgba(255,255,255,.07)}
.wp-sun-r{display:flex;justify-content:space-between;font-size:10px;color:#64748b;margin-bottom:8px}
.wp-arc{position:relative;height:7px;background:rgba(255,255,255,.07);border-radius:99px;overflow:visible;margin-bottom:14px}
.wp-arc-f{height:100%;border-radius:99px;background:linear-gradient(90deg,#3b82f6,#f59e0b,#ef4444)}
.wp-arc-d{position:absolute;top:-9px;font-size:19px;line-height:1;transition:left .5s}
.wp-week{padding:0 14px 14px}
.wp-wk-h{font-size:8px;text-transform:uppercase;letter-spacing:.1em;color:#475569;font-weight:700;margin-bottom:7px}
.wp-day{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.04);font-size:11px}
.wp-day:last-child{border-bottom:none}
.wp-day-n{width:70px;color:#64748b;font-size:10px;flex-shrink:0}
.wp-day-i{font-size:15px;flex-shrink:0}
.wp-day-b{flex:1;position:relative;height:3px;background:rgba(255,255,255,.07);border-radius:99px;margin:0 3px}
.wp-day-bf{position:absolute;height:100%;border-radius:99px;background:linear-gradient(90deg,#38bdf8,#ef4444)}
.wp-day-mn{color:#38bdf8;font-weight:700;font-size:10px;width:28px;text-align:right;flex-shrink:0}
.wp-day-mx{color:#ef4444;font-weight:700;font-size:10px;width:28px;text-align:right;flex-shrink:0}
.wp-day-r{font-size:9px;color:#475569;width:28px;text-align:right;flex-shrink:0}

/* Popup mer (au clic) */
.sp{font-family:'Inter',sans-serif;padding:16px;min-width:230px;max-width:min(280px,88vw)}
.sp-badge{font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:#38bdf8;margin-bottom:5px;font-weight:600}
.sp-name{font-size:14px;font-weight:700;color:#f1f5f9;margin-bottom:10px}
.sp-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.sp-card{background:rgba(14,30,60,.6);border-radius:7px;padding:8px 10px;border:1px solid rgba(56,189,248,.1)}
.sp-card-l{font-size:8px;text-transform:uppercase;letter-spacing:.07em;color:#475569;font-weight:600}
.sp-card-v{font-size:14px;font-weight:700;color:#7dd3fc;margin-top:2px}
.sp-card-s{font-size:9px;color:#475569;margin-top:1px}

/* Popup séisme/volcan/inondation */
.ep{font-family:'Inter',sans-serif;padding:15px;min-width:230px;max-width:min(280px,88vw)}
.ep-b{font-size:9px;text-transform:uppercase;letter-spacing:.07em;color:#64748b;margin-bottom:5px;font-weight:600}
.ep-t{font-size:13px;font-weight:600;color:#f1f5f9;margin-bottom:9px;line-height:1.4}
.ep-mag{font-size:32px;font-weight:300;line-height:1}
.ep-sub{font-size:10px;color:#64748b;line-height:1.7;margin-top:6px}

@media(max-width:480px){
  .wv-left{top:62px;left:8px}
  .wv-pnl{min-width:150px;padding:9px}
  .wv-bar{font-size:9px;padding:5px 10px}
}
`

/* ══════════════════════════════════════════════════════════════
   COMPOSANT
══════════════════════════════════════════════════════════════ */
export default function Home() {
  const mapRef      = useRef(null)
  const mapI        = useRef(null)
  const issMarker   = useRef(null)
  const issTimer    = useRef(null)
  const eqGroup     = useRef(null)
  const stormGroup  = useRef(null)
  const volcGroup   = useRef(null)
  const floodGroup  = useRef(null)
  const labelGroup  = useRef(null)   // étiquettes météo automatiques
  const labelCache  = useRef({})     // cache des données météo
  const labelTimers = useRef({})     // timers de refresh
  const zoomTimer   = useRef(null)

  const [loading,    setLoading]    = useState(true)
  const [issPos,     setIssPos]     = useState(null)
  const [eqCount,    setEqCount]    = useState(0)
  const [stormCount, setStormCount] = useState(0)
  const [volcCount,  setVolcCount]  = useState(0)
  const [lastUpd,    setLastUpd]    = useState('')
  const [layers, setLayers] = useState({
    labels:      true,
    earthquakes: true,
    storms:      true,
    iss:         true,
    volcanoes:   true,
    floods:      true,
  })
  const layersRef = useRef(layers)
  useEffect(() => { layersRef.current = layers }, [layers])

  /* ── Init Leaflet ────────────────────────────────────────── */
  useEffect(() => {
    if (typeof window === 'undefined' || mapI.current) return
    import('leaflet').then(({ default: L }) => {
      delete L.Icon.Default.prototype._getIconUrl
      L.Icon.Default.mergeOptions({
        iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
        iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
        shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      })

      const map = L.map(mapRef.current, {
        center: [25, 10], zoom: 2, minZoom: 2, maxZoom: 18,
        zoomControl: true, worldCopyJump: true,
      })

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© <a href="https://openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(map)

      mapI.current       = map
      eqGroup.current    = L.layerGroup().addTo(map)
      stormGroup.current = L.layerGroup().addTo(map)
      volcGroup.current  = L.layerGroup().addTo(map)
      floodGroup.current = L.layerGroup().addTo(map)
      labelGroup.current = L.layerGroup().addTo(map)

      // Clic sur carte → popup météo détaillé
      map.on('click', e => showDetailedWeather(L, map, e.latlng.lat, e.latlng.lng))

      // Zoom → rafraîchir les étiquettes
      map.on('zoomend moveend', () => {
        clearTimeout(zoomTimer.current)
        zoomTimer.current = setTimeout(() => updateLabels(L, map), 600)
      })

      setLoading(false)
      initAll(L, map)
    })
    return () => {
      if (issTimer.current) clearInterval(issTimer.current)
      clearTimeout(zoomTimer.current)
      if (mapI.current) { mapI.current.remove(); mapI.current = null }
    }
  }, [])

  /* ── Initialisation globale ───────────────────────────────── */
  const initAll = async (L, map) => {
    await Promise.all([
      updateLabels(L, map),
      loadEarthquakes(L, map),
      startISS(L, map),
      loadStorms(L, map),
      loadVolcanoes(L, map),
      loadFloods(L, map),
    ])
    setLastUpd(now())
    setInterval(async () => {
      await loadEarthquakes(L, map)
      await loadStorms(L, map)
      setLastUpd(now())
    }, 300000)
    // Rafraîchir les étiquettes toutes les 15 min
    setInterval(() => {
      labelCache.current = {}
      updateLabels(L, map)
    }, 900000)
  }

  const now = () => new Date().toLocaleTimeString('fr-FR', { hour:'2-digit', minute:'2-digit' })

  /* ── ÉTIQUETTES MÉTÉO AUTOMATIQUES ───────────────────────── */
  const updateLabels = useCallback(async (L, map) => {
    if (!layersRef.current.labels) return
    const zoom = map.getZoom()
    labelGroup.current.clearLayers()

    // Choisir les points selon le zoom
    let points = [...WEATHER_GRID[2]]
    if (zoom >= 4) points = [...points, ...WEATHER_GRID[4]]

    // Sur zoom élevé (≥ 6), filtrer aux points visibles dans le viewport
    const bounds = map.getBounds()
    const visible = points.filter(p =>
      p.lat >= bounds.getSouth() - 5 && p.lat <= bounds.getNorth() + 5 &&
      p.lon >= bounds.getWest() - 5  && p.lon <= bounds.getEast() + 5
    )

    // Limiter à 60 points max pour les performances
    const toLoad = visible.slice(0, 60)

    await Promise.all(toLoad.map(async (pt) => {
      try {
        const key = `${pt.lat.toFixed(1)}_${pt.lon.toFixed(1)}_${pt.sea}`
        let data = labelCache.current[key]

        if (!data) {
          if (pt.sea) {
            // Pour l'eau : météo marine + météo atmo
            const [marine, atmo] = await Promise.allSettled([
              fetchSeaWeather(pt.lat, pt.lon),
              fetchWeather(pt.lat, pt.lon),
            ])
            data = {
              sea: true,
              marine: marine.status === 'fulfilled' ? marine.value : null,
              atmo:   atmo.status   === 'fulfilled' ? atmo.value   : null,
            }
          } else {
            const w = await fetchWeather(pt.lat, pt.lon)
            data = { sea: false, weather: w }
          }
          labelCache.current[key] = data
        }

        if (!layersRef.current.labels) return

        const marker = pt.sea
          ? makeSeaLabel(L, pt, data, zoom)
          : makeLandLabel(L, pt, data, zoom)

        if (marker) marker.addTo(labelGroup.current)
      } catch { /* point ignoré si erreur */ }
    }))
  }, [])

  /* ── Étiquette TERRE ──────────────────────────────────────── */
  const makeLandLabel = (L, pt, data, zoom) => {
    const w = data.weather
    if (!w?.current) return null
    const c = w.current
    const [, emoji] = wmoLabel(c.weather_code)
    const sp = sunPos(pt.lat, pt.lon)
    const wd = windDir(c.wind_direction_10m)
    const [uvLbl] = uvLabel(c.uv_index)
    const sr = fmtTime(w.daily?.sunrise?.[0])
    const ss = fmtTime(w.daily?.sunset?.[0])

    // Selon le zoom, on montre plus ou moins d'infos
    const showFull  = zoom >= 6
    const showMed   = zoom >= 4
    const tempMax   = Math.round(w.daily?.temperature_2m_max?.[0] ?? c.temperature_2m)
    const tempMin   = Math.round(w.daily?.temperature_2m_min?.[0] ?? c.temperature_2m)

    const html = `
      <div class="wv-label" style="cursor:pointer;">
        <div class="wv-label-city">${pt.name}</div>
        <div class="wv-label-temp">${emoji} ${Math.round(c.temperature_2m)}°C</div>
        <div class="wv-label-row">
          <span class="wv-label-badge">↓${tempMin}° ↑${tempMax}°</span>
          ${showMed ? `<span class="wv-label-badge">💨 ${Math.round(c.wind_speed_10m)}km/h ${wd}</span>` : ''}
          ${showFull ? `<span class="wv-label-badge">💧 ${c.relative_humidity_2m}%</span>` : ''}
        </div>
        ${showMed ? `<div class="wv-label-row">
          ${c.uv_index != null ? `<span class="wv-label-badge">☀️ UV ${c.uv_index?.toFixed(0)} ${uvLbl}</span>` : ''}
          ${showFull ? `<span class="wv-label-badge">${sp.isDaytime?'☀️':'🌙'} ${sp.altitude}°</span>` : ''}
        </div>` : ''}
        ${showFull ? `<div class="wv-label-row">
          <span class="wv-label-badge">🌅 ${sr}</span>
          <span class="wv-label-badge">🌇 ${ss}</span>
        </div>` : ''}
      </div>
    `
    return L.marker([pt.lat, pt.lon], {
      icon: L.divIcon({ html, className:'', iconAnchor:[45, 20] }),
      interactive: true,
      zIndexOffset: 200,
    }).on('click', e => {
      e.originalEvent.stopPropagation()
      if (mapI.current) showDetailedWeather(L, mapI.current, pt.lat, pt.lon, pt.name)
    })
  }

  /* ── Étiquette MER ────────────────────────────────────────── */
  const makeSeaLabel = (L, pt, data, zoom) => {
    const marine = data.marine?.current
    const atmo   = data.atmo?.current
    const temp   = marine?.sea_surface_temperature
    const waveH  = marine?.wave_height
    const waveD  = marine?.wave_direction
    const atmoT  = atmo?.temperature_2m
    const windKh = atmo ? Math.round(atmo.wind_speed_10m) : null
    const wd     = atmo ? windDir(atmo.wind_direction_10m) : ''

    const [stateLbl] = waveH != null
      ? (waveH < 0.5 ? ['Calme'] : waveH < 1.25 ? ['Belle'] : waveH < 2.5 ? ['Peu agitée'] : waveH < 4 ? ['Agitée'] : ['Très agitée'])
      : ['?']

    const showMed = zoom >= 4

    const html = `
      <div class="wv-sea-label" style="cursor:pointer;">
        <div class="wv-sea-name">${pt.name}</div>
        ${temp != null ? `<div class="wv-sea-temp">🌡️ ${temp.toFixed(1)}°C</div>` : ''}
        <div class="wv-sea-row">${waveH != null ? `🌊 ${waveH.toFixed(1)}m · ${stateLbl}` : ''}</div>
        ${showMed && windKh ? `<div class="wv-sea-row">💨 ${windKh} km/h ${wd}</div>` : ''}
        ${showMed && atmoT != null ? `<div class="wv-sea-row">🌬️ Air ${Math.round(atmoT)}°C</div>` : ''}
      </div>
    `
    return L.marker([pt.lat, pt.lon], {
      icon: L.divIcon({ html, className:'', iconAnchor:[45, 20] }),
      interactive: true,
      zIndexOffset: 100,
    }).on('click', e => {
      e.originalEvent.stopPropagation()
      if (mapI.current) showSeaPopup(L, mapI.current, pt, data)
    })
  }

  /* ── Popup mer détaillé (au clic) ────────────────────────── */
  const showSeaPopup = (L, map, pt, data) => {
    const marine = data.marine?.current
    const atmo   = data.atmo?.current
    const temp   = marine?.sea_surface_temperature
    const waveH  = marine?.wave_height
    const waveD  = marine?.wave_direction
    const wavePd = marine?.wave_period
    const windWH = marine?.wind_wave_height
    const atmoT  = atmo?.temperature_2m
    const windKh = atmo ? Math.round(atmo.wind_speed_10m) : '–'
    const wd     = atmo ? windDir(atmo.wind_direction_10m) : '–'
    const [uvLbl, uvCol] = atmo ? uvLabel(atmo.uv_index) : ['–','#64748b']
    const sp     = sunPos(pt.lat, pt.lon)

    const [stateLbl] = waveH != null
      ? waveH < 0.1 ? ["Mer d'huile"] : waveH < 0.5 ? ['Calme'] : waveH < 1.25 ? ['Belle'] : waveH < 2.5 ? ['Peu agitée'] : waveH < 4 ? ['Agitée'] : waveH < 6 ? ['Très agitée'] : ['Grosse mer']
      : ['?']

    const cards = [
      ['🌡️ Eau', temp != null ? `${temp.toFixed(1)}°C` : '–', ''],
      ['🌊 Vagues', waveH != null ? `${waveH.toFixed(1)} m` : '–', stateLbl],
      ['💨 Vent', `${windKh} km/h`, wd],
      ['🌬️ Air', atmoT != null ? `${Math.round(atmoT)}°C` : '–', ''],
      ['⏱️ Période', wavePd != null ? `${wavePd.toFixed(0)}s` : '–', 'vagues'],
      ['☀️ UV', atmo?.uv_index != null ? atmo.uv_index.toFixed(1) : '–', uvLbl],
      ['💧 Humidité', atmo?.relative_humidity_2m != null ? `${atmo.relative_humidity_2m}%` : '–', ''],
      [sp.isDaytime ? '☀️ Soleil' : '🌙 Lune', `${sp.altitude}°`, sp.isDaytime ? 'Altitude' : 'Nuit'],
    ]

    L.popup({ maxWidth: 300, closeButton: true })
      .setLatLng([pt.lat, pt.lon])
      .setContent(`
        <div class="sp">
          <div class="sp-badge">🌊 Données marines & météo</div>
          <div class="sp-name">${pt.name}</div>
          <div class="sp-grid">
            ${cards.map(([l, v, s]) => `
              <div class="sp-card">
                <div class="sp-card-l">${l}</div>
                <div class="sp-card-v">${v}</div>
                ${s ? `<div class="sp-card-s">${s}</div>` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      `)
      .openOn(map)
  }

  /* ── Popup météo terrestre détaillé (au clic) ─────────────── */
  const showDetailedWeather = async (L, map, lat, lng, cityName) => {
    try {
      const w = await fetchWeather(lat, lng)
      const { current: c, daily: d, timezone } = w
      const [desc, emoji] = wmoLabel(c.weather_code)
      const wd  = windDir(c.wind_direction_10m)
      const sp  = sunPos(lat, lng)
      const sr  = fmtTime(d.sunrise?.[0])
      const ss  = fmtTime(d.sunset?.[0])
      const spP = Math.max(0, Math.min(100, ((sp.altitude + 90) / 180) * 100))
      const [uvLbl, uvCol] = uvLabel(c.uv_index)

      const gMin = Math.min(...d.temperature_2m_min)
      const gMax = Math.max(...d.temperature_2m_max)
      const span = gMax - gMin || 1

      const weekRows = d.time.map((t, i) => {
        const [, emo2] = wmoLabel(d.weather_code[i])
        const mn = Math.round(d.temperature_2m_min[i])
        const mx = Math.round(d.temperature_2m_max[i])
        const bL = ((d.temperature_2m_min[i] - gMin) / span * 100).toFixed(1)
        const bW = ((d.temperature_2m_max[i] - d.temperature_2m_min[i]) / span * 100).toFixed(1)
        const rain = d.precipitation_probability_max?.[i]
        return `
          <div class="wp-day">
            <div class="wp-day-n">${fmtDay(t, i)}</div>
            <div class="wp-day-i">${emo2}</div>
            <div class="wp-day-b"><div class="wp-day-bf" style="left:${bL}%;width:${bW}%"></div></div>
            <div class="wp-day-mn">${mn}°</div>
            <div class="wp-day-mx">${mx}°</div>
            <div class="wp-day-r">${rain != null ? rain + '%' : ''}</div>
          </div>`
      }).join('')

      L.popup({ maxWidth: 360, autoPan: true, closeButton: true })
        .setLatLng([lat, lng])
        .setContent(`
          <div class="wp">
            <div class="wp-hd">
              <div class="wp-coord">${cityName ? cityName + ' — ' : ''}${lat.toFixed(3)}°, ${lng.toFixed(3)}°</div>
              <div class="wp-tz">${timezone?.replace(/_/g,' ') ?? ''}</div>
            </div>
            <div class="wp-main">
              <div class="wp-emo">${emoji}</div>
              <div class="wp-tmp">${Math.round(c.temperature_2m)}<sup>°C</sup></div>
              <div class="wp-feels">Ressenti ${Math.round(c.apparent_temperature)}°C</div>
              <div class="wp-dsc">${desc}</div>
              <div class="wp-mm">
                <span style="color:#38bdf8;font-weight:700;font-size:12px;">↓ ${Math.round(d.temperature_2m_min[0])}°</span>
                <span style="color:#ef4444;font-weight:700;font-size:12px;">↑ ${Math.round(d.temperature_2m_max[0])}°</span>
              </div>
            </div>
            <div class="wp-grid">
              <div class="wp-c"><div class="wp-c-i">💨</div><div class="wp-c-l">Vent</div>
                <div class="wp-c-v">${Math.round(c.wind_speed_10m)}<span style="font-size:10px;font-weight:400;color:#475569"> km/h</span></div>
                <div class="wp-c-s">${wd} · ${c.wind_direction_10m}°</div></div>
              <div class="wp-c"><div class="wp-c-i">🌞</div><div class="wp-c-l">Indice UV</div>
                <div class="wp-c-v" style="color:${uvCol}">${c.uv_index?.toFixed(1) ?? '–'}</div>
                <div class="wp-c-s" style="color:${uvCol}">${uvLbl}</div></div>
              <div class="wp-c"><div class="wp-c-i">💧</div><div class="wp-c-l">Humidité</div>
                <div class="wp-c-v">${c.relative_humidity_2m}<span style="font-size:10px;font-weight:400;color:#475569">%</span></div>
                <div class="wp-c-s">Relative</div></div>
              <div class="wp-c"><div class="wp-c-i">🌧️</div><div class="wp-c-l">Précip. jour</div>
                <div class="wp-c-v">${d.precipitation_sum?.[0]?.toFixed(1) ?? '0'}<span style="font-size:10px;font-weight:400;color:#475569"> mm</span></div>
                <div class="wp-c-s">${c.precipitation > 0 ? c.precipitation + ' mm/h en cours' : 'Aucune en cours'}</div></div>
            </div>
            <div class="wp-sun">
              <div class="wp-sun-r">
                <span>🌅 ${sr}</span>
                <span style="color:#f1f5f9;font-weight:600">${sp.isDaytime ? '☀️ Jour' : '🌙 Nuit'} · ${sp.altitude}° alt.</span>
                <span>🌇 ${ss}</span>
              </div>
              <div class="wp-arc">
                <div class="wp-arc-f" style="width:${spP}%"></div>
                <div class="wp-arc-d" style="left:calc(${spP}% - 10px)">${sp.isDaytime ? '☀️' : '🌑'}</div>
              </div>
            </div>
            <div class="wp-week">
              <div class="wp-wk-h">📅 Prévisions 7 jours</div>
              ${weekRows}
            </div>
          </div>
        `)
        .openOn(map)
    } catch (err) { console.error('Météo détaillée:', err) }
  }

  /* ── Séismes ───────────────────────────────────────────────── */
  const loadEarthquakes = async (L, map) => {
    try {
      const data = await fetchEarthquakes()
      const features = data.features || []
      setEqCount(features.length)
      eqGroup.current.clearLayers()
      features.forEach(f => {
        const [lng, lat, depth] = f.geometry.coordinates
        const mag   = parseFloat(f.properties.mag)
        const place = f.properties.place
        const time  = new Date(f.properties.time)
        const tsun  = f.properties.tsunami
        const col   = magColor(mag)
        const sz    = magSize(mag)
        const marine = /ocean|sea|ridge|trench/i.test(place)
        L.circleMarker([lat, lng], { radius: sz * 1.8, color: col, fillColor: col, fillOpacity: .1, weight: 0, interactive: false }).addTo(eqGroup.current)
        L.circleMarker([lat, lng], { radius: sz, color: '#0b1120', fillColor: col, fillOpacity: .92, weight: 1.5 })
          .bindPopup(`<div class="ep">
            <div class="ep-b">${marine ? '🌊 Séisme maritime' : '🌍 Séisme terrestre'}${tsun ? ' · ⚠️ Tsunami' : ''}</div>
            <div class="ep-t">${place}</div>
            <div class="ep-mag" style="color:${col}">M${mag.toFixed(1)}</div>
            <div class="ep-sub">
              📅 ${time.toLocaleDateString('fr-FR', { day:'2-digit', month:'long' })} ${time.toLocaleTimeString('fr-FR', { hour:'2-digit', minute:'2-digit' })} UTC<br>
              📍 ${lat.toFixed(3)}°, ${lng.toFixed(3)}° — Prof. ${depth?.toFixed(0) ?? '?'} km
            </div>
          </div>`, { maxWidth: 290 })
          .on('click', e => e.originalEvent.stopPropagation())
          .addTo(eqGroup.current)
      })
    } catch (e) { console.error(e) }
  }

  /* ── ISS ───────────────────────────────────────────────────── */
  const startISS = async (L, map) => {
    const upd = async () => {
      try {
        const d = await fetchISS()
        setIssPos({ lat: d.latitude, lon: d.longitude })
        const ico = L.divIcon({
          html: `<div style="font-size:26px;animation:orbit 3s ease-in-out infinite;filter:drop-shadow(0 2px 10px rgba(56,189,248,.7))">🛸</div>`,
          className: '', iconSize: [30, 30], iconAnchor: [15, 15],
        })
        const pop = `<div class="ep">
          <div class="ep-b">🛸 ISS — Temps réel</div>
          <div class="ep-t">Station Spatiale Internationale</div>
          <div class="ep-sub">
            🛰️ Altitude : ${Math.round(d.altitude)} km<br>
            ⚡ Vitesse : ${Math.round(d.velocity)} km/h<br>
            📍 ${d.latitude.toFixed(3)}°, ${d.longitude.toFixed(3)}°
          </div>
        </div>`
        if (!issMarker.current) {
          issMarker.current = L.marker([d.latitude, d.longitude], { icon: ico, zIndexOffset: 1000 })
            .bindPopup(pop, { maxWidth: 260 }).addTo(map)
        } else {
          issMarker.current.setLatLng([d.latitude, d.longitude])
          issMarker.current.setIcon(ico)
          issMarker.current.setPopupContent(pop)
        }
      } catch (e) { console.error(e) }
    }
    await upd()
    issTimer.current = setInterval(upd, 10000)
  }

  /* ── Tempêtes ──────────────────────────────────────────────── */
  const loadStorms = async (L, map) => {
    try {
      const data = await fetchStorms()
      setStormCount(data.length)
      stormGroup.current.clearLayers()
      data.forEach(s => {
        const lat = s.latitude || s.lat, lng = s.longitude || s.lon
        if (!lat || !lng) return
        const ico = L.divIcon({
          html: `<div style="font-size:28px;animation:spin 8s linear infinite;filter:drop-shadow(0 0 10px rgba(167,139,250,.9))">🌀</div>`,
          className: '', iconSize: [34, 34], iconAnchor: [17, 17],
        })
        L.marker([lat, lng], { icon: ico })
          .bindPopup(`<div class="ep">
            <div class="ep-b">🌀 Tempête tropicale active</div>
            <div class="ep-t">${s.name || 'Sans nom'}</div>
            <div class="ep-sub">${s.intensity ? '⚡ Intensité : ' + s.intensity + ' nœuds' : ''}${s.type ? '<br>📊 ' + s.type : ''}</div>
          </div>`, { maxWidth: 260 })
          .on('click', e => e.originalEvent.stopPropagation())
          .addTo(stormGroup.current)
      })
    } catch (e) { console.error(e) }
  }

  /* ── Volcans ───────────────────────────────────────────────── */
  const loadVolcanoes = async (L, map) => {
    const data = getVolcanoes()
    setVolcCount(data.length)
    data.forEach(v => {
      const col = alertCol(v.alert)
      const ico = L.divIcon({
        html: `<div style="position:relative;display:flex;align-items:center;justify-content:center;width:32px;height:32px;">
          <div style="position:absolute;width:32px;height:32px;border-radius:50%;background:${col};opacity:.18;animation:pulse 2.2s ease-in-out infinite;"></div>
          <span style="font-size:20px;line-height:1;">🌋</span>
        </div>`,
        className: '', iconSize: [32, 32], iconAnchor: [16, 16],
      })
      L.marker([v.lat, v.lon], { icon: ico })
        .bindPopup(`<div class="ep">
          <div class="ep-b" style="color:${col}">🌋 Volcan — Alerte ${v.alert.toUpperCase()}</div>
          <div class="ep-t">${v.name}</div>
          <div class="ep-sub">🌍 ${v.country}<br>📊 ${v.status}<br>⛰️ Altitude : ${v.elev.toLocaleString()} m</div>
        </div>`, { maxWidth: 270 })
        .on('click', e => e.originalEvent.stopPropagation())
        .addTo(volcGroup.current)
    })
  }

  /* ── Inondations ───────────────────────────────────────────── */
  const loadFloods = async (L, map) => {
    const data = getFloods()
    data.forEach(f => {
      const col = alertCol(f.alert)
      const ico = L.divIcon({
        html: `<div style="position:relative;display:flex;align-items:center;justify-content:center;width:34px;height:34px;">
          <div style="position:absolute;width:34px;height:34px;border-radius:50%;background:${col};opacity:.15;animation:pulse 2.5s ease-in-out infinite;"></div>
          <span style="font-size:21px;line-height:1;">💧</span>
        </div>`,
        className: '', iconSize: [34, 34], iconAnchor: [17, 17],
      })
      L.marker([f.lat, f.lon], { icon: ico })
        .bindPopup(`<div class="ep">
          <div class="ep-b" style="color:${col}">💧 Inondation — Alerte ${f.alert.toUpperCase()}</div>
          <div class="ep-t">${f.name}</div>
          <div class="ep-sub">🌍 ${f.country}</div>
        </div>`, { maxWidth: 270 })
        .on('click', e => e.originalEvent.stopPropagation())
        .addTo(floodGroup.current)
    })
  }

  /* ── Globe 3D ──────────────────────────────────────────────── */
  const openGlobe = () => {
    const w = window.open('', '_blank', 'width=980,height=700,menubar=no,toolbar=no')
    w.document.write(`<!DOCTYPE html><html><head><title>WorldView Globe 3D</title>
    <script src="https://cesium.com/downloads/cesiumjs/releases/1.117/Build/Cesium/Cesium.js"></script>
    <link href="https://cesium.com/downloads/cesiumjs/releases/1.117/Build/Cesium/Widgets/widgets.css" rel="stylesheet">
    <style>html,body,#c{width:100%;height:100%;margin:0;padding:0;overflow:hidden;}
    #lbl{position:absolute;top:12px;left:50%;transform:translateX(-50%);background:rgba(11,17,32,.92);color:#f1f5f9;font-family:'Inter',sans-serif;font-size:12px;font-weight:600;padding:7px 18px;border-radius:99px;border:1px solid rgba(255,255,255,.1);pointer-events:none;white-space:nowrap}</style>
    </head><body><div id="c"></div><div id="lbl">🌍 Globe 3D WorldView</div>
    <script>Cesium.Ion.defaultAccessToken='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJlYWE1OWUxNy1mMWZiLTQzYjYtYTQ0OS1kMWFjYmFkNjc4ZDkiLCJpZCI6NTc3MzMsImlhdCI6MTYyMjY0NDA0Mn0.XcKpgANiY19MC4bdFUXMVEBToBmqS8kuYpUlxJHYZxk';
    const v=new Cesium.Viewer('c',{animation:false,baseLayerPicker:true,fullscreenButton:true,geocoder:true,homeButton:true,infoBox:false,sceneModePicker:true,selectionIndicator:false,timeline:false});
    v.scene.globe.enableLighting=true;v.camera.flyHome(2);</script></body></html>`)
    w.document.close()
  }

  /* ── Toggle couches ────────────────────────────────────────── */
  const toggle = useCallback((key) => {
    const map = mapI.current
    if (!map) return
    const next = !layers[key]
    setLayers(p => ({ ...p, [key]: next }))
    const groups = { earthquakes: eqGroup, storms: stormGroup, volcanoes: volcGroup, floods: floodGroup }
    if (key === 'labels') {
      if (next) {
        labelGroup.current.addTo(map)
        import('leaflet').then(({ default: L }) => updateLabels(L, map))
      } else { labelGroup.current.remove() }
    } else if (key === 'iss') {
      if (issMarker.current) next ? issMarker.current.addTo(map) : issMarker.current.remove()
    } else if (groups[key]?.current) {
      next ? groups[key].current.addTo(map) : groups[key].current.remove()
    }
  }, [layers, updateLabels])

  /* ── Rendu ─────────────────────────────────────────────────── */
  return (
    <>
      <Head>
        <title>WorldView — Météo mondiale en temps réel</title>
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1" />
      </Head>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />

      <div className="wv">
        {loading && (
          <div className="wv-load">
            <div className="wv-spin" />
            <div className="wv-load-t">Chargement WorldView…</div>
          </div>
        )}

        {/* Header */}
        <header className="wv-hdr">
          <div className="wv-logo">
            <em>🌍</em>
            <div>
              <div className="wv-logo-n">WorldView</div>
              <div className="wv-logo-t">Météo &amp; Terre · Temps réel</div>
            </div>
          </div>
          <div className="wv-hint">
            Les infos météo s'affichent automatiquement · Cliquez pour les détails + 7 jours
          </div>
        </header>

        {/* Carte */}
        <div ref={mapRef} className="wv-map" />

        {/* Panneau gauche */}
        <div className="wv-left">
          {/* Globe */}
          <div className="wv-pnl">
            <div className="wv-pnl-h">Vue</div>
            <button className="wv-gbtn" onClick={openGlobe}>
              <em>🌍</em><span>Globe 3D ↗</span>
            </button>
          </div>

          {/* Couches */}
          <div className="wv-pnl">
            <div className="wv-pnl-h">Couches</div>
            {[
              { k:'labels',      i:'🏷️', l:'Météo auto' },
              { k:'earthquakes', i:'🔴', l:'Séismes'    },
              { k:'volcanoes',   i:'🌋', l:'Volcans'    },
              { k:'floods',      i:'💧', l:'Inondations'},
              { k:'storms',      i:'🌀', l:'Tempêtes'   },
              { k:'iss',         i:'🛸', l:'ISS'        },
            ].map(({ k, i, l }) => (
              <button key={k} className="wv-tog" onClick={() => toggle(k)}>
                <em>{i}</em><span>{l}</span>
                <div className={`wv-sw${layers[k] ? ' on' : ''}`} />
              </button>
            ))}
          </div>

          {/* Légende séismes */}
          <div className="wv-pnl">
            <div className="wv-pnl-h">Magnitude séisme</div>
            {[['#22c55e','< 3.0'],['#eab308','3–4'],['#f97316','4–5'],['#ef4444','5–6'],['#7c3aed','≥ 6']].map(([c, l]) => (
              <div key={l} className="wv-leg"><span className="wv-leg-d" style={{ background: c }} /><span>{l}</span></div>
            ))}
          </div>

          {/* Légende alertes */}
          <div className="wv-pnl">
            <div className="wv-pnl-h">Niveau alerte 🌋💧</div>
            {[['#22c55e','Surveillance'],['#eab308','Modéré'],['#f97316','Élevé'],['#ef4444','Critique']].map(([c, l]) => (
              <div key={l} className="wv-leg"><span className="wv-leg-d" style={{ background: c }} /><span style={{ fontSize: '9px' }}>{l}</span></div>
            ))}
          </div>
        </div>

        {/* Barre basse */}
        <div className="wv-bar">
          <span className="wv-bar-dot" style={{ background:'#ef4444' }} />
          <span>{eqCount} séisme{eqCount !== 1 ? 's' : ''}</span>
          <div className="wv-bar-sep" />
          <span className="wv-bar-dot" style={{ background:'#f97316' }} />
          <span>{volcCount} volcan{volcCount !== 1 ? 's' : ''}</span>
          <div className="wv-bar-sep" />
          <span className="wv-bar-dot" style={{ background:'#a78bfa' }} />
          <span>{stormCount} tempête{stormCount !== 1 ? 's' : ''}</span>
          <div className="wv-bar-sep" />
          <span>🛸 {issPos ? `${issPos.lat.toFixed(1)}°, ${issPos.lon.toFixed(1)}°` : '—'}</span>
          {lastUpd && <><div className="wv-bar-sep" /><span style={{ color:'#334155' }}>Màj {lastUpd}</span></>}
        </div>
      </div>
    </>
  )
}
